create view view_school_teacher as
  SELECT rst.schoolid,
    dh.unionid,
    dboe.unionid AS boeid,
    dso.org_id AS boeorg,
    dso.org_name AS orgname,
    ds.country,
    ds.city,
    dh.edu_level AS edulevel,
    dh.job_title AS jobtitle,
    dh.job_situation AS jobsituation
   FROM ((((relation_school_teacher rst
     LEFT JOIN data_school ds ON (((rst.schoolid)::text = (ds.unionid)::text)))
     LEFT JOIN data_humen dh ON (((rst.teacherid)::text = (dh.unionid)::text)))
     LEFT JOIN data_bureau_of_education dboe ON (((dboe.unionid)::text = (ds.boe_id)::text)))
     LEFT JOIN data_org dso ON ((dso.org_id = (dboe.org_id)::numeric)));

