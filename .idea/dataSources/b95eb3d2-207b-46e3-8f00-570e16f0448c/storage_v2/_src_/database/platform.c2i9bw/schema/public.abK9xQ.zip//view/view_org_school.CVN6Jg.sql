create view view_org_school as
  SELECT vob.base,
    vob.base_name AS basename,
    vba.orgid,
    vba.country,
    vba.city,
    ds.unionid AS schoolid,
    ds.name AS schoolname
   FROM ((view_org_base vob
     LEFT JOIN view_boe_all vba ON ((vob.base = vba.orgid)))
     LEFT JOIN data_school ds ON (((ds.boe_id)::text = (vba.boeid)::text)));

