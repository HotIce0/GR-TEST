create view view_school_all as
  SELECT dso.org_id AS orgid,
    dso.org_name AS orgname,
    dboe.unionid AS boeid,
    ds.unionid AS schoolid,
    ds.name AS schoolname
   FROM ((data_org dso
     LEFT JOIN data_bureau_of_education dboe ON ((dso.org_id = (dboe.org_id)::numeric)))
     LEFT JOIN data_school ds ON (((ds.boe_id)::text = (dboe.unionid)::text)));

