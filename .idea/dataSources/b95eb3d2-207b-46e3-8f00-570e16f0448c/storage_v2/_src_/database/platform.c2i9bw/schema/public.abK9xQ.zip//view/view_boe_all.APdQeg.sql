create view view_boe_all as
  SELECT dboe.unionid AS boeid,
    dboe.name AS boename,
    vob.base AS orgid,
    vob.base_name AS orgname,
    vob.country,
    vob.xian,
    vob.city,
    vob.shizhou
   FROM (data_bureau_of_education dboe
     LEFT JOIN view_org_base vob ON (((dboe.org_id)::numeric = vob.base)));

