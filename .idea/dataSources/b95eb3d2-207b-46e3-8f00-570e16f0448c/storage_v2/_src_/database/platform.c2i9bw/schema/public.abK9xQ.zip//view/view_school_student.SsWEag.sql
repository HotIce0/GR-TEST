create view view_school_student as
  SELECT ds.unionid AS schoolid,
    dsc.unionid AS clazzid,
    dh.unionid,
    dboe.unionid AS boeid,
    dso.org_id AS boeorg,
    dso.org_name AS orgname,
    dso.org_level AS orglevel,
    ds.country,
    ds.city,
    dsc.period,
    dsc.year AS grade,
    dsc.name AS clazz,
    dh.is_live_school AS isliveschool,
    dh.is_poor AS ispoor,
    dh.is_stay_child AS isstaychild,
    dh.is_drop_out AS isdropout,
    dh.study_way AS studyway,
    dh.entrance,
    dh.graduation
   FROM (((((relation_class_student rcs
     LEFT JOIN data_school_class dsc ON (((rcs.classid)::text = (dsc.unionid)::text)))
     LEFT JOIN data_school ds ON (((ds.unionid)::text = (dsc.school_id)::text)))
     LEFT JOIN data_humen dh ON (((rcs.studentid)::text = (dh.unionid)::text)))
     LEFT JOIN data_bureau_of_education dboe ON (((dboe.unionid)::text = (ds.boe_id)::text)))
     LEFT JOIN data_org dso ON ((dso.org_id = (dboe.org_id)::numeric)));

