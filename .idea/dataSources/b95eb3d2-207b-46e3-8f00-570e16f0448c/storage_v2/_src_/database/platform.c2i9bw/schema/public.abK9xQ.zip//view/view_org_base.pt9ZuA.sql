create view view_org_base as
  SELECT sheng.org_name AS sheng,
    ''::character varying AS shizhou,
    0 AS city,
    ''::text AS xian,
    0 AS country,
    sheng.org_name AS base_name,
    sheng.org_id AS base,
    sheng.org_level AS orglevel,
    sheng.longitude,
    sheng.latitude
   FROM data_org sheng
  WHERE (sheng.org_level = (1)::numeric)
UNION
 SELECT sheng.org_name AS sheng,
    shizhou.org_name AS shizhou,
    shizhou.org_id AS city,
    ''::text AS xian,
    0 AS country,
    shizhou.org_name AS base_name,
    shizhou.org_id AS base,
    shizhou.org_level AS orglevel,
    shizhou.longitude,
    shizhou.latitude
   FROM (data_org shizhou
     LEFT JOIN data_org sheng ON ((sheng.org_id = shizhou.parent_id)))
  WHERE (shizhou.org_level = (2)::numeric)
UNION
 SELECT sheng.org_name AS sheng,
    shizhou.org_name AS shizhou,
    shizhou.org_id AS city,
    xian.org_name AS xian,
    xian.org_id AS country,
    xian.org_name AS base_name,
    xian.org_id AS base,
    xian.org_level AS orglevel,
    xian.longitude,
    xian.latitude
   FROM ((data_org xian
     LEFT JOIN data_org shizhou ON ((shizhou.org_id = xian.parent_id)))
     LEFT JOIN data_org sheng ON ((sheng.org_id = shizhou.parent_id)))
  WHERE (xian.org_level = (3)::numeric)
  ORDER BY 2, 4;

