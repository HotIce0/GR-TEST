create view view_outbound as
  SELECT nfs.school_id,
    nfs.food_id AS foodid,
    nf.food_code AS foodcode,
    nf.food_name AS foodname,
    max((nfs.price_unit)::text) AS priceunit,
    sum(nfs.storage_number) AS storagenumber,
    sum(nfs.money) AS money,
    nfs.year AS years,
    nfs.month AS months
   FROM (nm_food_storage nfs
     LEFT JOIN nm_food nf ON (((nf.id)::numeric = nfs.food_id)))
  WHERE (nfs.storage_type = (2)::numeric)
  GROUP BY nfs.school_id, nfs.food_id, nf.food_name, nf.food_code, nfs.year, nfs.month
  ORDER BY nfs.food_id;

